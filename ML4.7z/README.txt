In terminal:

javac Attack_b64.java
java Attack_b64